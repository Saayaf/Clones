"use client"

import { useState } from "react"
import Image from "next/image"
import { Menu, X } from "lucide-react"

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Image
            src="https://copilot.microsoft.com/_nuxt/microsoft-logo.5ba85859.svg"
            alt="Microsoft logo"
            width={32}
            height={32}
          />
          <span className="ml-2 text-xl font-semibold">Microsoft Copilot</span>
        </div>
        <nav className="hidden md:flex space-x-6">
          <a href="#" className="text-gray-600 hover:text-gray-900">
            Overview
          </a>
          <a href="#" className="text-gray-600 hover:text-gray-900">
            Pricing
          </a>
          <a href="#" className="text-gray-600 hover:text-gray-900">
            Documentation
          </a>
          <a href="#" className="text-gray-600 hover:text-gray-900">
            Support
          </a>
        </nav>
        <div className="hidden md:flex items-center space-x-4">
          <a href="#" className="text-blue-600 hover:text-blue-800">
            Sign in
          </a>
          <a href="#" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
            Get started
          </a>
        </div>
        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-white py-2">
          <nav className="flex flex-col space-y-2 px-4">
            <a href="#" className="text-gray-600 hover:text-gray-900 py-2">
              Overview
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 py-2">
              Pricing
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 py-2">
              Documentation
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 py-2">
              Support
            </a>
            <a href="#" className="text-blue-600 hover:text-blue-800 py-2">
              Sign in
            </a>
            <a href="#" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 text-center">
              Get started
            </a>
          </nav>
        </div>
      )}
    </header>
  )
}

export default Header

