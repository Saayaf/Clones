"use client"

import { useState } from "react"
import Image from "next/image"
import ChatBox from "./ChatBox"

const Hero = () => {
  const [isChatOpen, setIsChatOpen] = useState(false)

  return (
    <section className="bg-gradient-to-r from-blue-500 to-purple-600 text-white py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Microsoft Copilot</h1>
            <p className="text-xl mb-8">Your AI-powered chat assistant for Microsoft 365</p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <button
                onClick={() => setIsChatOpen(true)}
                className="bg-white text-blue-600 px-6 py-3 rounded-md font-semibold hover:bg-gray-100 text-center"
              >
                Get started
              </button>
              <a
                href="#"
                className="border border-white text-white px-6 py-3 rounded-md font-semibold hover:bg-white hover:text-blue-600 text-center"
              >
                Learn more
              </a>
            </div>
          </div>
          <div className="md:w-1/2">
            <Image
              src="https://copilot.microsoft.com/_nuxt/hero-desktop.5e14eec9.png"
              alt="Copilot illustration"
              width={500}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
      {isChatOpen && <ChatBox onClose={() => setIsChatOpen(false)} />}
    </section>
  )
}

export default Hero

