import Image from "next/image"

const features = [
  {
    icon: "/productivity.svg",
    title: "AI-powered productivity",
    description: "Get more done in less time with AI-assisted writing, analysis, and task management.",
  },
  {
    icon: "/integration.svg",
    title: "Seamless integration",
    description: "Works across your favorite Microsoft 365 apps, providing a consistent experience.",
  },
  {
    icon: "/security.svg",
    title: "Enterprise-grade security",
    description: "Your data is protected with advanced security and compliance features.",
  },
]

const Features = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-blue-600 mb-4">
                <Image src={feature.icon || "/placeholder.svg"} alt={feature.title} width={40} height={40} />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Features

